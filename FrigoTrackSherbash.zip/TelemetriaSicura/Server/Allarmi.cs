using Comune;

namespace Server;

// Controlla se la temperatura è nell'intervallo di sicurezza del tipo di merce
public static class Allarmi
{
    // Restituisce il testo dell'allarme, oppure null se la temperatura è regolare.
    // Per i farmaci l'intervallo (2-8 °C) è quello della consegna; gli altri due sono valori scelti da noi.
    public static string? Controlla(MisuraSensore misura)
    {
        double minimo;
        double massimo;

        switch (misura.TipoMerce)
        {
            case "pharma":
                minimo = 2;
                massimo = 8;
                break;
            case "food":
                minimo = 0;
                massimo = 4;
                break;
            default: // frozen
                minimo = -25;
                massimo = -18;
                break;
        }

        if (misura.Temperatura < minimo || misura.Temperatura > massimo)
            return $"Temperatura {misura.Temperatura} °C fuori dall'intervallo di sicurezza ({minimo} / {massimo} °C) per {misura.TipoMerce}";

        return null;
    }
}
