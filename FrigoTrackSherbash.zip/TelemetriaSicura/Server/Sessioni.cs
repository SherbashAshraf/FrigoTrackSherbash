using System.Collections.Concurrent;
using System.Numerics;

namespace Server;

// Archivio delle sessioni aperte: ogni client ha il proprio id e il proprio segreto condiviso.
// ConcurrentDictionary permette di gestire più client contemporanei senza problemi.
public static class Sessioni
{
    public static readonly ConcurrentDictionary<string, BigInteger> Elenco = new();
}
