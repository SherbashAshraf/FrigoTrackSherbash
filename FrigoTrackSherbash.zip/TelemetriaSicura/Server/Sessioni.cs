using System.Collections.Concurrent;

namespace Server;

// Archivio delle sessioni aperte: per ogni id di sessione si tiene la chiave AES del client.
// ConcurrentDictionary permette di gestire più client contemporanei senza problemi.
public static class Sessioni
{
    public static readonly ConcurrentDictionary<string, byte[]> Elenco = new();
}
