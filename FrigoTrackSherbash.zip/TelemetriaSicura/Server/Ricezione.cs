using System.Text.Json;
using Comune;

namespace Server;

// I primi controlli sono uguali per tutti gli endpoint che ricevono una busta cifrata
public static class Ricezione
{
    // Apre la busta ricevuta. Restituisce null se tutto è andato bene (e riempie i parametri out),
    // altrimenti la risposta di errore da inviare al client.
    public static IResult? ApriBusta(JsonElement corpo, out string idSessione, out byte[] chiave, out string testoInChiaro)
    {
        idSessione = "";
        chiave = Array.Empty<byte>();
        testoInChiaro = "";

        // 1. La busta deve rispettare lo schema busta.json
        ErroreValidazione? erroreBusta = ValidatoreSchema.Valida("busta", corpo.GetRawText());
        if (erroreBusta is not null)
            return Risposte.ErroreInChiaro(400, erroreBusta.Messaggio, erroreBusta.Campo);

        BustaCifrata busta = corpo.Deserialize<BustaCifrata>()!;

        // 2. Sessione sconosciuta (mai aperta o già chiusa): il client non è autenticato
        if (!Sessioni.Elenco.TryGetValue(busta.IdSessione, out byte[]? chiaveSessione))
            return Risposte.ErroreInChiaro(401, "Sessione inesistente");

        // 3. Prima si decifra: se la decifratura o il tag falliscono, 400 e non si elabora nulla
        string? testo = Cifratura.Decifra(busta, chiaveSessione);
        if (testo is null)
            return Risposte.ErroreInChiaro(400, "Busta non valida o manomessa");

        idSessione = busta.IdSessione;
        chiave = chiaveSessione;
        testoInChiaro = testo;
        return null;
    }
}
