using System.Numerics;
using System.Security.Cryptography;
using Comune;
using Server;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Fase 1 del protocollo: handshake Diffie-Hellman
app.MapPost("/api/handshake", (RichiestaHandshake richiesta) =>
{
    BigInteger? p = DiffieHellman.DaEsadecimale(richiesta.P);
    BigInteger? g = DiffieHellman.DaEsadecimale(richiesta.G);
    BigInteger? chiavePubblicaClient = DiffieHellman.DaEsadecimale(richiesta.ChiavePubblicaClient);

    // Il server accetta solo il gruppo noto (RFC 3526)
    if (p != DiffieHellman.P || g != DiffieHellman.G)
        return Results.BadRequest(new { errore = "Parametri p e g non accettati" });

    if (chiavePubblicaClient is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaClient.Value))
        return Results.BadRequest(new { errore = "Campo A non valido" });

    // Il server sceglie il proprio segreto b e calcola B = g^b mod p
    BigInteger segretoServer = DiffieHellman.GeneraSegreto();
    BigInteger chiavePubblicaServer = DiffieHellman.CalcolaChiavePubblica(segretoServer);

    // Segreto condiviso K = A^b mod p (non viaggia mai in rete)
    BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaClient.Value, segretoServer);

    // Identificativo di sessione casuale, es. "a3f9c2e1"
    string idSessione = Convert.ToHexString(RandomNumberGenerator.GetBytes(4)).ToLower();
    Sessioni.Elenco[idSessione] = segretoCondiviso;

    Console.WriteLine($"Nuova sessione {idSessione} - impronta chiave: {DiffieHellman.ImprontaSegreto(segretoCondiviso)}");

    return Results.Ok(new RispostaHandshake(idSessione, DiffieHellman.InEsadecimale(chiavePubblicaServer)));
});

app.Run("http://localhost:5000");
