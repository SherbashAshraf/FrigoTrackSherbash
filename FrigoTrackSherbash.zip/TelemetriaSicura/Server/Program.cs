using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using Comune;
using Server;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Fase 1 del protocollo: handshake Diffie-Hellman
app.MapPost("/api/handshake", (RichiestaHandshake richiesta) =>
{
    BigInteger? p = DiffieHellman.DaEsadecimale(richiesta.P);
    BigInteger? g = DiffieHellman.DaEsadecimale(richiesta.G);
    BigInteger? chiavePubblicaClient = DiffieHellman.DaEsadecimale(richiesta.ChiavePubblicaClient);

    // Il server accetta solo il gruppo noto (RFC 3526)
    if (p != DiffieHellman.P || g != DiffieHellman.G)
        return Results.BadRequest(new { errore = "Parametri p e g non accettati" });

    if (chiavePubblicaClient is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaClient.Value))
        return Results.BadRequest(new { errore = "Campo A non valido" });

    // Il server sceglie il proprio segreto b e calcola B = g^b mod p
    BigInteger segretoServer = DiffieHellman.GeneraSegreto();
    BigInteger chiavePubblicaServer = DiffieHellman.CalcolaChiavePubblica(segretoServer);

    // Segreto condiviso K = A^b mod p (non viaggia mai in rete) e chiave AES derivata
    BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaClient.Value, segretoServer);
    byte[] chiave = Cifratura.DerivaChiave(segretoCondiviso);

    // Identificativo di sessione casuale, es. "a3f9c2e1"
    string idSessione = Convert.ToHexString(RandomNumberGenerator.GetBytes(4)).ToLower();
    Sessioni.Elenco[idSessione] = chiave;

    Console.WriteLine($"Nuova sessione {idSessione}");

    return Results.Ok(new RispostaHandshake(idSessione, DiffieHellman.InEsadecimale(chiavePubblicaServer)));
});

// Fase 2 del protocollo: invio di una misura cifrata
app.MapPost("/api/telemetry", (BustaCifrata busta) =>
{
    // La busta deve avere tutti i campi
    if (string.IsNullOrEmpty(busta.IdSessione) || string.IsNullOrEmpty(busta.TestoCifrato) || string.IsNullOrEmpty(busta.Tag))
        return Results.Json(new { errore = "Busta incompleta" }, statusCode: 400);

    // Sessione sconosciuta: il client non è autenticato
    if (!Sessioni.Elenco.TryGetValue(busta.IdSessione, out byte[]? chiave))
        return Results.Json(new { errore = "Sessione inesistente" }, statusCode: 401);

    // Prima si decifra: se la decifratura o il tag falliscono, 400 e non si elabora nulla
    string? testoInChiaro = Cifratura.Decifra(busta, chiave);
    if (testoInChiaro is null)
        return Results.Json(new { errore = "Busta non valida o manomessa" }, statusCode: 400);

    // Solo ora si legge il JSON applicativo (la validazione con JSON Schema arriva nel prossimo commit)
    MisuraSensore? misura;
    try
    {
        misura = JsonSerializer.Deserialize<MisuraSensore>(testoInChiaro);
    }
    catch (JsonException)
    {
        misura = null;
    }

    if (misura is null)
        return Results.Json(new { errore = "Messaggio non valido" }, statusCode: 400);

    Console.WriteLine($"Misura da {misura.IdSensore}: {misura.Temperatura} °C (sessione {busta.IdSessione})");

    // Conferma (ack) restituita anch'essa cifrata
    string ack = JsonSerializer.Serialize(new { esito = "ok" });
    return Results.Ok(Cifratura.Cifra(busta.IdSessione, ack, chiave));
});

app.Run("http://localhost:5000");
