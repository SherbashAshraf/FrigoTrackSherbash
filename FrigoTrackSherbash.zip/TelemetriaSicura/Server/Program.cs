using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using Comune;
using Server;

var builder = WebApplication.CreateBuilder(args);

// Nella console del server restano solo i nostri messaggi (senza il log di ogni richiesta HTTP)
builder.Logging.SetMinimumLevel(LogLevel.Warning);

var app = builder.Build();

// Fase 1 del protocollo: handshake Diffie-Hellman
app.MapPost("/api/handshake", (JsonElement corpo) =>
{
    // Ogni messaggio in ingresso viene validato con il suo schema
    ErroreValidazione? errore = ValidatoreSchema.Valida("richiesta-handshake", corpo.GetRawText());
    if (errore is not null)
        return Risposte.ErroreInChiaro(400, errore.Messaggio, errore.Campo);

    RichiestaHandshake richiesta = corpo.Deserialize<RichiestaHandshake>()!;

    BigInteger? p = DiffieHellman.DaEsadecimale(richiesta.P);
    BigInteger? g = DiffieHellman.DaEsadecimale(richiesta.G);
    BigInteger? chiavePubblicaClient = DiffieHellman.DaEsadecimale(richiesta.ChiavePubblicaClient);

    // Il server accetta solo il gruppo noto (RFC 3526)
    if (p != DiffieHellman.P || g != DiffieHellman.G)
        return Risposte.ErroreInChiaro(400, "Parametri p e g non accettati", "p");

    if (chiavePubblicaClient is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaClient.Value))
        return Risposte.ErroreInChiaro(400, "Chiave pubblica non valida", "A");

    // Il server sceglie il proprio segreto b e calcola B = g^b mod p
    BigInteger segretoServer = DiffieHellman.GeneraSegreto();
    BigInteger chiavePubblicaServer = DiffieHellman.CalcolaChiavePubblica(segretoServer);

    // Segreto condiviso K = A^b mod p (non viaggia mai in rete) e chiave AES derivata
    BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaClient.Value, segretoServer);
    byte[] chiave = Cifratura.DerivaChiave(segretoCondiviso);

    // Identificativo di sessione casuale, es. "a3f9c2e1"
    string idSessione = Convert.ToHexString(RandomNumberGenerator.GetBytes(4)).ToLower();
    Sessioni.Elenco[idSessione] = chiave;

    Console.WriteLine($"Nuova sessione {idSessione}");

    return Results.Ok(new RispostaHandshake(idSessione, DiffieHellman.InEsadecimale(chiavePubblicaServer)));
});

// Fase 2: invio di una misura cifrata
app.MapPost("/api/telemetry", (JsonElement corpo) =>
{
    // Busta, sessione e decifratura (errori 400 o 401)
    IResult? erroreBusta = Ricezione.ApriBusta(corpo, out string idSessione, out byte[] chiave, out string testoInChiaro);
    if (erroreBusta is not null)
        return erroreBusta;

    // Solo dopo la decifratura si valida il messaggio con lo schema misura.json
    ErroreValidazione? erroreMisura = ValidatoreSchema.Valida("misura", testoInChiaro);
    if (erroreMisura is not null)
    {
        Console.WriteLine($"Misura rifiutata (sessione {idSessione}), campo: {erroreMisura.Campo}");
        return Risposte.ErroreCifrato(400, erroreMisura, idSessione, chiave);
    }

    MisuraSensore misura = JsonSerializer.Deserialize<MisuraSensore>(testoInChiaro)!;
    ArchivioMisure.Salva(misura);

    // Se la temperatura esce dall'intervallo di sicurezza la risposta contiene un allarme
    string? testoAllarme = Allarmi.Controlla(misura);
    Console.WriteLine($"Misura da {misura.IdSensore}: {misura.Temperatura} °C (sessione {idSessione})");
    if (testoAllarme is not null)
        Console.WriteLine($"  ALLARME: {testoAllarme}");

    RispostaAck ack = new RispostaAck { Esito = "ok", Allarme = testoAllarme is not null, Messaggio = testoAllarme };
    return Risposte.OkCifrato(idSessione, chiave, ack);
});

// Fase 2: richiesta delle misure di un sensore in un intervallo di tempo
app.MapPost("/api/readings", (JsonElement corpo) =>
{
    IResult? erroreBusta = Ricezione.ApriBusta(corpo, out string idSessione, out byte[] chiave, out string testoInChiaro);
    if (erroreBusta is not null)
        return erroreBusta;

    ErroreValidazione? erroreRichiesta = ValidatoreSchema.Valida("richiesta-readings", testoInChiaro);
    if (erroreRichiesta is not null)
        return Risposte.ErroreCifrato(400, erroreRichiesta, idSessione, chiave);

    RichiestaLetture richiesta = JsonSerializer.Deserialize<RichiestaLetture>(testoInChiaro)!;

    // Sensore che non ha mai inviato misure: 404
    if (!ArchivioMisure.Esiste(richiesta.IdSensore))
        return Risposte.ErroreCifrato(404, new ErroreValidazione("sensor_id", "Sensore sconosciuto"), idSessione, chiave);

    if (!DateTimeOffset.TryParse(richiesta.Da, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTimeOffset da))
        return Risposte.ErroreCifrato(400, new ErroreValidazione("from", "Data non valida"), idSessione, chiave);

    if (!DateTimeOffset.TryParse(richiesta.A, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTimeOffset a))
        return Risposte.ErroreCifrato(400, new ErroreValidazione("to", "Data non valida"), idSessione, chiave);

    if (da > a)
        return Risposte.ErroreCifrato(400, new ErroreValidazione("from", "from deve essere precedente a to"), idSessione, chiave);

    List<MisuraSensore> trovate = ArchivioMisure.Cerca(richiesta.IdSensore, da, a);

    RispostaLetture risposta = new RispostaLetture
    {
        IdSensore = richiesta.IdSensore,
        Conteggio = trovate.Count,
        Misure = trovate
    };
    return Risposte.OkCifrato(idSessione, chiave, risposta);
});

// Fase 2: chiusura della sessione e cancellazione della chiave
app.MapPost("/api/close", (JsonElement corpo) =>
{
    IResult? erroreBusta = Ricezione.ApriBusta(corpo, out string idSessione, out byte[] chiave, out string testoInChiaro);
    if (erroreBusta is not null)
        return erroreBusta;

    ErroreValidazione? erroreRichiesta = ValidatoreSchema.Valida("richiesta-close", testoInChiaro);
    if (erroreRichiesta is not null)
        return Risposte.ErroreCifrato(400, erroreRichiesta, idSessione, chiave);

    // La risposta va cifrata PRIMA di cancellare la chiave
    IResult risposta = Risposte.OkCifrato(idSessione, chiave, new RispostaAck { Esito = "ok" });

    // Cancellazione: la sessione sparisce dall'archivio e i byte della chiave vengono azzerati
    Sessioni.Elenco.TryRemove(idSessione, out _);
    CryptographicOperations.ZeroMemory(chiave);

    Console.WriteLine($"Sessione {idSessione} chiusa, chiave cancellata");
    return risposta;
});

app.Run("http://localhost:5000");
