using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using Comune;
using Server;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// Fase 1 del protocollo: handshake Diffie-Hellman
app.MapPost("/api/handshake", (JsonElement corpo) =>
{
    // Ogni messaggio in ingresso viene validato con il suo schema
    ErroreValidazione? errore = ValidatoreSchema.Valida("richiesta-handshake", corpo.GetRawText());
    if (errore is not null)
        return Risposte.ErroreInChiaro(400, errore.Messaggio, errore.Campo);

    RichiestaHandshake richiesta = corpo.Deserialize<RichiestaHandshake>()!;

    BigInteger? p = DiffieHellman.DaEsadecimale(richiesta.P);
    BigInteger? g = DiffieHellman.DaEsadecimale(richiesta.G);
    BigInteger? chiavePubblicaClient = DiffieHellman.DaEsadecimale(richiesta.ChiavePubblicaClient);

    // Il server accetta solo il gruppo noto (RFC 3526)
    if (p != DiffieHellman.P || g != DiffieHellman.G)
        return Risposte.ErroreInChiaro(400, "Parametri p e g non accettati", "p");

    if (chiavePubblicaClient is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaClient.Value))
        return Risposte.ErroreInChiaro(400, "Chiave pubblica non valida", "A");

    // Il server sceglie il proprio segreto b e calcola B = g^b mod p
    BigInteger segretoServer = DiffieHellman.GeneraSegreto();
    BigInteger chiavePubblicaServer = DiffieHellman.CalcolaChiavePubblica(segretoServer);

    // Segreto condiviso K = A^b mod p (non viaggia mai in rete) e chiave AES derivata
    BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaClient.Value, segretoServer);
    byte[] chiave = Cifratura.DerivaChiave(segretoCondiviso);

    // Identificativo di sessione casuale, es. "a3f9c2e1"
    string idSessione = Convert.ToHexString(RandomNumberGenerator.GetBytes(4)).ToLower();
    Sessioni.Elenco[idSessione] = chiave;

    Console.WriteLine($"Nuova sessione {idSessione}");

    return Results.Ok(new RispostaHandshake(idSessione, DiffieHellman.InEsadecimale(chiavePubblicaServer)));
});

// Fase 2 del protocollo: invio di una misura cifrata
app.MapPost("/api/telemetry", (JsonElement corpo) =>
{
    // 1. La busta deve rispettare lo schema busta.json
    ErroreValidazione? erroreBusta = ValidatoreSchema.Valida("busta", corpo.GetRawText());
    if (erroreBusta is not null)
        return Risposte.ErroreInChiaro(400, erroreBusta.Messaggio, erroreBusta.Campo);

    BustaCifrata busta = corpo.Deserialize<BustaCifrata>()!;

    // 2. Sessione sconosciuta: il client non è autenticato
    if (!Sessioni.Elenco.TryGetValue(busta.IdSessione, out byte[]? chiave))
        return Risposte.ErroreInChiaro(401, "Sessione inesistente");

    // 3. Prima si decifra: se la decifratura o il tag falliscono, 400 e non si elabora nulla
    string? testoInChiaro = Cifratura.Decifra(busta, chiave);
    if (testoInChiaro is null)
        return Risposte.ErroreInChiaro(400, "Busta non valida o manomessa");

    // 4. Solo dopo si valida il messaggio con lo schema misura.json
    ErroreValidazione? erroreMisura = ValidatoreSchema.Valida("misura", testoInChiaro);
    if (erroreMisura is not null)
    {
        Console.WriteLine($"Misura rifiutata (sessione {busta.IdSessione}), campo: {erroreMisura.Campo}");
        return Risposte.ErroreCifrato(400, erroreMisura, busta.IdSessione, chiave);
    }

    MisuraSensore misura = JsonSerializer.Deserialize<MisuraSensore>(testoInChiaro)!;
    Console.WriteLine($"Misura da {misura.IdSensore}: {misura.Temperatura} °C (sessione {busta.IdSessione})");

    // Conferma (ack) restituita anch'essa cifrata
    string ack = JsonSerializer.Serialize(new { esito = "ok" });
    return Results.Ok(Cifratura.Cifra(busta.IdSessione, ack, chiave));
});

app.Run("http://localhost:5000");
