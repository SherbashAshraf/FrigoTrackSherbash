using System.Text.Json;
using Comune;

namespace Server;

// Costruisce le risposte di errore del server (formato dello schema errore.json)
public static class Risposte
{
    // Errore in chiaro: si usa quando non c'è ancora una chiave affidabile
    // (busta non valida, sessione inesistente, tag errato, handshake)
    public static IResult ErroreInChiaro(int codice, string errore, string? campo = null)
    {
        MessaggioErrore messaggio = new MessaggioErrore { Codice = codice, Errore = errore, Campo = campo };
        return Results.Json(messaggio, statusCode: codice);
    }

    // Errore cifrato: si usa dopo la decifratura. Il motivo può contenere il valore
    // sbagliato inviato dal sensore, quindi non deve viaggiare in chiaro.
    public static IResult ErroreCifrato(int codice, ErroreValidazione problema, string idSessione, byte[] chiave)
    {
        MessaggioErrore messaggio = new MessaggioErrore { Codice = codice, Errore = problema.Messaggio, Campo = problema.Campo };
        string json = JsonSerializer.Serialize(messaggio);
        return Results.Json(Cifratura.Cifra(idSessione, json, chiave), statusCode: codice);
    }
}
