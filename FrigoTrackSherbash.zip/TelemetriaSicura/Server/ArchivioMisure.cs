using System.Globalization;
using System.Text.Json;
using Comune;

namespace Server;

// Salva le misure ricevute nel file dati/misure.json e le rende consultabili.
// Tutti gli accessi passano da un lock, perché più client scrivono contemporaneamente.
public static class ArchivioMisure
{
    private static readonly object bloccoArchivio = new();
    private static readonly string percorsoFile = Path.Combine(AppContext.BaseDirectory, "dati", "misure.json");
    private static readonly List<MisuraSensore> misure = CaricaDaFile();

    // All'avvio riprende le misure salvate dalle esecuzioni precedenti
    private static List<MisuraSensore> CaricaDaFile()
    {
        if (!File.Exists(percorsoFile))
            return new List<MisuraSensore>();

        return JsonSerializer.Deserialize<List<MisuraSensore>>(File.ReadAllText(percorsoFile)) ?? new List<MisuraSensore>();
    }

    // Aggiunge la misura e riscrive il file
    public static void Salva(MisuraSensore misura)
    {
        lock (bloccoArchivio)
        {
            misure.Add(misura);

            Directory.CreateDirectory(Path.GetDirectoryName(percorsoFile)!);
            JsonSerializerOptions opzioni = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(percorsoFile, JsonSerializer.Serialize(misure, opzioni));
        }
    }

    // Vero se il sensore ha già inviato almeno una misura
    public static bool Esiste(string idSensore)
    {
        lock (bloccoArchivio)
        {
            return misure.Any(m => m.IdSensore == idSensore);
        }
    }

    // Misure di un sensore comprese tra due istanti (estremi inclusi), in ordine di tempo
    public static List<MisuraSensore> Cerca(string idSensore, DateTimeOffset da, DateTimeOffset a)
    {
        lock (bloccoArchivio)
        {
            List<MisuraSensore> trovate = new();

            foreach (MisuraSensore misura in misure)
            {
                if (misura.IdSensore != idSensore)
                    continue;

                if (!DateTimeOffset.TryParse(misura.DataOra, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTimeOffset istante))
                    continue;

                if (istante >= da && istante <= a)
                    trovate.Add(misura);
            }

            return trovate.OrderBy(m => m.DataOra).ToList();
        }
    }
}
