using System.Text.Json.Serialization;

namespace Comune;

// Busta cifrata: è l'unica cosa che viaggia in rete dopo l'handshake.
// ciphertext contiene il nonce seguito dal testo cifrato; tag garantisce
// che il messaggio non sia stato modificato. Tutto è codificato in Base64.
public record BustaCifrata(
    [property: JsonPropertyName("session_id")] string IdSessione,
    [property: JsonPropertyName("ciphertext")] string TestoCifrato,
    [property: JsonPropertyName("tag")] string Tag);

// Messaggio applicativo inviato dal sensore (prima di essere cifrato).
// I campi facoltativi vuoti non vengono scritti nel JSON.
public class MisuraSensore
{
    [JsonPropertyName("sensor_id")]
    public string? IdSensore { get; set; }

    [JsonPropertyName("timestamp")]
    public string? DataOra { get; set; }

    [JsonPropertyName("cargo_type")]
    public string? TipoMerce { get; set; }

    [JsonPropertyName("temperature_c")]
    public double Temperatura { get; set; }

    [JsonPropertyName("humidity")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public double? Umidita { get; set; }

    [JsonPropertyName("battery")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? Batteria { get; set; }
}

// Messaggio di errore restituito dal server (schema errore.json)
public class MessaggioErrore
{
    [JsonPropertyName("codice")]
    public int Codice { get; set; }

    [JsonPropertyName("errore")]
    public string Errore { get; set; } = "";

    // Indica il campo sbagliato (solo per gli errori di validazione)
    [JsonPropertyName("campo")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Campo { get; set; }
}

// Risposta del server a una richiesta andata a buon fine (schema ack.json).
// Per le misure indica se la temperatura è fuori dall'intervallo di sicurezza.
public class RispostaAck
{
    [JsonPropertyName("esito")]
    public string Esito { get; set; } = "ok";

    [JsonPropertyName("allarme")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public bool? Allarme { get; set; }

    [JsonPropertyName("messaggio")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Messaggio { get; set; }
}

// Richiesta a /api/readings: sensore e intervallo di tempo (schema richiesta-readings.json)
public class RichiestaLetture
{
    [JsonPropertyName("sensor_id")]
    public string IdSensore { get; set; } = "";

    [JsonPropertyName("from")]
    public string Da { get; set; } = "";

    [JsonPropertyName("to")]
    public string A { get; set; } = "";
}

// Risposta di /api/readings: le misure trovate (schema risposta-readings.json)
public class RispostaLetture
{
    [JsonPropertyName("sensor_id")]
    public string IdSensore { get; set; } = "";

    [JsonPropertyName("count")]
    public int Conteggio { get; set; }

    [JsonPropertyName("readings")]
    public List<MisuraSensore> Misure { get; set; } = new();
}

// Richiesta a /api/close (schema richiesta-close.json)
public class RichiestaChiusura
{
    [JsonPropertyName("azione")]
    public string Azione { get; set; } = "close";
}
