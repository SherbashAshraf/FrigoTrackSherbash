using System.Text.Json.Serialization;

namespace Comune;

// Busta cifrata: è l'unica cosa che viaggia in rete dopo l'handshake.
// ciphertext contiene il nonce seguito dal testo cifrato; tag garantisce
// che il messaggio non sia stato modificato. Tutto è codificato in Base64.
public record BustaCifrata(
    [property: JsonPropertyName("session_id")] string IdSessione,
    [property: JsonPropertyName("ciphertext")] string TestoCifrato,
    [property: JsonPropertyName("tag")] string Tag);

// Messaggio applicativo inviato dal sensore (prima di essere cifrato).
// I campi facoltativi vuoti non vengono scritti nel JSON.
public class MisuraSensore
{
    [JsonPropertyName("sensor_id")]
    public string? IdSensore { get; set; }

    [JsonPropertyName("timestamp")]
    public string? DataOra { get; set; }

    [JsonPropertyName("cargo_type")]
    public string? TipoMerce { get; set; }

    [JsonPropertyName("temperature_c")]
    public double Temperatura { get; set; }

    [JsonPropertyName("humidity")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public double? Umidita { get; set; }

    [JsonPropertyName("battery")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? Batteria { get; set; }
}

// Messaggio di errore restituito dal server (schema errore.json)
public class MessaggioErrore
{
    [JsonPropertyName("codice")]
    public int Codice { get; set; }

    [JsonPropertyName("errore")]
    public string Errore { get; set; } = "";

    // Indica il campo sbagliato (solo per gli errori di validazione)
    [JsonPropertyName("campo")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Campo { get; set; }
}
