using System.Globalization;
using System.Numerics;
using System.Security.Cryptography;

namespace Comune;

// Scambio di chiavi Diffie-Hellman scritto a mano.
// Si usa solo BigInteger.ModPow (potenza modulare), come ammesso dalla consegna.
public static class DiffieHellman
{
    // Primo p del gruppo 14 (2048 bit) di RFC 3526, paragrafo 3
    private const string PrimoEsadecimale =
        "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74" +
        "020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437" +
        "4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
        "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05" +
        "98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB" +
        "9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
        "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718" +
        "3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF";

    public static readonly BigInteger P = DaEsadecimale(PrimoEsadecimale)!.Value;
    public static readonly BigInteger G = 2;

    // Genera il segreto casuale (a per il client, b per il server): 256 bit
    public static BigInteger GeneraSegreto()
    {
        byte[] byteCasuali = RandomNumberGenerator.GetBytes(32);
        BigInteger segreto = new BigInteger(byteCasuali, isUnsigned: true, isBigEndian: true);
        return segreto + 2; // evita i valori 0 e 1
    }

    // Chiave pubblica: A = g^a mod p (oppure B = g^b mod p)
    public static BigInteger CalcolaChiavePubblica(BigInteger segreto)
    {
        return BigInteger.ModPow(G, segreto, P);
    }

    // Segreto condiviso: K = B^a mod p (oppure K = A^b mod p)
    public static BigInteger CalcolaSegretoCondiviso(BigInteger chiavePubblicaAltro, BigInteger mioSegreto)
    {
        return BigInteger.ModPow(chiavePubblicaAltro, mioSegreto, P);
    }

    // Una chiave pubblica ricevuta deve stare tra 2 e p-2, altrimenti è sospetta
    public static bool ChiavePubblicaValida(BigInteger chiavePubblica)
    {
        return chiavePubblica > 1 && chiavePubblica < P - 1;
    }

    // In rete i numeri grandi viaggiano come stringhe esadecimali
    public static string InEsadecimale(BigInteger numero)
    {
        return numero.ToString("X");
    }

    // Restituisce null se il testo non è un esadecimale valido
    public static BigInteger? DaEsadecimale(string? testo)
    {
        if (string.IsNullOrWhiteSpace(testo))
            return null;

        // Lo "0" iniziale serve perché BigInteger consideri il numero positivo
        if (BigInteger.TryParse("0" + testo, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out BigInteger valore))
            return valore;

        return null;
    }
}
