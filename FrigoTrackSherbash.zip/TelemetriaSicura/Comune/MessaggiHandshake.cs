using System.Text.Json.Serialization;

namespace Comune;

// Corpo della richiesta POST /api/handshake (tutto in chiaro, come da consegna)
public record RichiestaHandshake(
    [property: JsonPropertyName("p")] string P,
    [property: JsonPropertyName("g")] string G,
    [property: JsonPropertyName("A")] string ChiavePubblicaClient);

// Risposta del server: identificativo di sessione e chiave pubblica B
public record RispostaHandshake(
    [property: JsonPropertyName("session_id")] string IdSessione,
    [property: JsonPropertyName("B")] string ChiavePubblicaServer);
