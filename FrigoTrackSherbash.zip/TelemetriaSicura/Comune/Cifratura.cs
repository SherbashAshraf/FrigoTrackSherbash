using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace Comune;

// Cifratura dei messaggi con AES-GCM: cifra e produce anche il tag di autenticazione.
// Se qualcuno modifica la busta in rete, la decifratura fallisce.
public static class Cifratura
{
    private const int LunghezzaNonce = 12;
    private const int LunghezzaTag = 16;

    // Dal segreto condiviso K (2048 bit) ricava una chiave AES da 256 bit
    public static byte[] DerivaChiave(BigInteger segretoCondiviso)
    {
        return SHA256.HashData(segretoCondiviso.ToByteArray());
    }

    // Cifra un testo (il JSON applicativo) e lo mette in una busta
    public static BustaCifrata Cifra(string idSessione, string testoInChiaro, byte[] chiave)
    {
        byte[] dati = Encoding.UTF8.GetBytes(testoInChiaro);
        byte[] nonce = RandomNumberGenerator.GetBytes(LunghezzaNonce); // nuovo per ogni messaggio
        byte[] cifrato = new byte[dati.Length];
        byte[] tag = new byte[LunghezzaTag];

        using AesGcm aes = new AesGcm(chiave, LunghezzaTag);
        aes.Encrypt(nonce, dati, cifrato, tag);

        // Il nonce non è segreto: lo mettiamo davanti al testo cifrato
        byte[] nonceECifrato = nonce.Concat(cifrato).ToArray();

        return new BustaCifrata(
            idSessione,
            Convert.ToBase64String(nonceECifrato),
            Convert.ToBase64String(tag));
    }

    // Decifra una busta. Restituisce null se il Base64 è sbagliato o se
    // il tag non corrisponde (busta manomessa o chiave errata).
    public static string? Decifra(BustaCifrata busta, byte[] chiave)
    {
        try
        {
            byte[] nonceECifrato = Convert.FromBase64String(busta.TestoCifrato);
            byte[] tag = Convert.FromBase64String(busta.Tag);

            if (nonceECifrato.Length < LunghezzaNonce || tag.Length != LunghezzaTag)
                return null;

            byte[] nonce = nonceECifrato[..LunghezzaNonce];
            byte[] cifrato = nonceECifrato[LunghezzaNonce..];
            byte[] dati = new byte[cifrato.Length];

            using AesGcm aes = new AesGcm(chiave, LunghezzaTag);
            aes.Decrypt(nonce, cifrato, tag, dati);

            return Encoding.UTF8.GetString(dati);
        }
        catch (FormatException)
        {
            return null; // Base64 non valido
        }
        catch (CryptographicException)
        {
            return null; // tag non valido: busta manomessa
        }
    }
}
