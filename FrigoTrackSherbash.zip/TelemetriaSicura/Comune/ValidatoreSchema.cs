using System.Text.Json;
using Json.Schema;

namespace Comune;

// Descrive il primo errore trovato: quale campo è sbagliato e perché
public record ErroreValidazione(string Campo, string Messaggio);

// Validazione dei messaggi con JSON Schema (libreria JsonSchema.Net).
// Gli schemi sono nella cartella schemas/ e si indicano per nome file, senza estensione.
public static class ValidatoreSchema
{
    // Ogni schema viene costruito una sola volta e poi riutilizzato
    private static readonly Dictionary<string, JsonSchema> schemiCaricati = new();
    private static readonly object bloccoSchemi = new();

    private static JsonSchema CaricaSchema(string nomeSchema)
    {
        lock (bloccoSchemi)
        {
            if (!schemiCaricati.TryGetValue(nomeSchema, out JsonSchema? schema))
            {
                string percorso = Path.Combine(AppContext.BaseDirectory, "schemas", nomeSchema + ".json");
                JsonElement jsonSchema = JsonDocument.Parse(File.ReadAllText(percorso)).RootElement;

                // Un registro nuovo per ogni schema evita conflitti tra schemi diversi
                BuildOptions opzioniCostruzione = new BuildOptions
                {
                    Dialect = Dialect.Draft202012,
                    SchemaRegistry = new SchemaRegistry()
                };

                schema = JsonSchema.Build(jsonSchema, opzioniCostruzione);
                schemiCaricati[nomeSchema] = schema;
            }

            return schema;
        }
    }

    // Controlla un testo JSON con lo schema indicato.
    // Restituisce null se il messaggio è valido, altrimenti il campo sbagliato e il motivo.
    public static ErroreValidazione? Valida(string nomeSchema, string testoJson)
    {
        JsonElement messaggio;
        try
        {
            messaggio = JsonDocument.Parse(testoJson).RootElement;
        }
        catch (JsonException)
        {
            return new ErroreValidazione("(messaggio)", "Il messaggio non è un JSON valido");
        }

        JsonSchema schema = CaricaSchema(nomeSchema);

        // List: elenco semplice degli errori. RequireFormatValidation: controlla davvero "format" (es. date-time)
        EvaluationOptions opzioni = new EvaluationOptions
        {
            OutputFormat = OutputFormat.List,
            RequireFormatValidation = true
        };

        EvaluationResults risultato = schema.Evaluate(messaggio, opzioni);
        if (risultato.IsValid)
            return null;

        // Si raccolgono i nodi del risultato che contengono almeno un errore
        List<EvaluationResults> nodi = new() { risultato };
        if (risultato.Details != null)
            nodi.AddRange(risultato.Details);

        List<EvaluationResults> conErrori = nodi.Where(n => n.Errors != null && n.Errors.Count > 0).ToList();

        // Si preferisce l'errore che punta a un campo preciso (es. /temperature_c)
        EvaluationResults? scelto = conErrori.FirstOrDefault(n => n.InstanceLocation.ToString() != "")
                                    ?? conErrori.FirstOrDefault();

        if (scelto is null)
            return new ErroreValidazione("(messaggio)", "Il messaggio non rispetta lo schema");

        string campo = scelto.InstanceLocation.ToString().TrimStart('/');
        if (campo == "")
            campo = "(messaggio)"; // errore sull'intero oggetto, es. campo obbligatorio mancante

        string motivo = scelto.Errors!.First().Value;
        return new ErroreValidazione(campo, motivo);
    }
}
