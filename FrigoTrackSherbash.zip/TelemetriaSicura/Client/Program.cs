Console.WriteLine("=== Client sensori FrigoTrack ===");

HttpClient http = new HttpClient { BaseAddress = new Uri("http://localhost:5000") };

// Tre sensori con identificativo diverso: ognuno fa il proprio handshake e ha la propria chiave
List<Sensore> sensori = new()
{
    new Sensore(http, "CELLA-BG-001", "pharma", 5.0) { Dimostrazione = true },
    new Sensore(http, "CAMION-BS-002", "food", 2.0) { ProvocaAllarme = true },
    new Sensore(http, "CELLA-MI-003", "frozen", -20.0)
};

const int numeroMisure = 5;
const int pausaMillisecondi = 2000; // intervallo regolare tra una misura e la successiva

// I sensori lavorano contemporaneamente
await Task.WhenAll(sensori.Select(sensore => sensore.Esegui(numeroMisure, pausaMillisecondi)));

Console.WriteLine("\nSimulazione terminata");
