using System.Net.Http.Json;
using System.Numerics;
using Comune;

Console.WriteLine("=== Client sensori FrigoTrack ===");

HttpClient http = new HttpClient { BaseAddress = new Uri("http://localhost:5000") };

// Passo 1: il client sceglie il segreto a e calcola A = g^a mod p
BigInteger segretoClient = DiffieHellman.GeneraSegreto();
BigInteger chiavePubblicaClient = DiffieHellman.CalcolaChiavePubblica(segretoClient);

RichiestaHandshake richiesta = new RichiestaHandshake(
    DiffieHellman.InEsadecimale(DiffieHellman.P),
    DiffieHellman.InEsadecimale(DiffieHellman.G),
    DiffieHellman.InEsadecimale(chiavePubblicaClient));

// Passo 2: invio ad /api/handshake (p, g e A viaggiano in chiaro)
HttpResponseMessage risposta = await http.PostAsJsonAsync("/api/handshake", richiesta);

if (!risposta.IsSuccessStatusCode)
{
    Console.WriteLine($"Handshake fallito: {(int)risposta.StatusCode}");
    return;
}

RispostaHandshake? datiRisposta = await risposta.Content.ReadFromJsonAsync<RispostaHandshake>();
BigInteger? chiavePubblicaServer = DiffieHellman.DaEsadecimale(datiRisposta?.ChiavePubblicaServer);

if (datiRisposta is null || chiavePubblicaServer is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaServer.Value))
{
    Console.WriteLine("Risposta del server non valida");
    return;
}

// Passo 3: K = B^a mod p
BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaServer.Value, segretoClient);

Console.WriteLine($"Sessione {datiRisposta.IdSessione} - impronta chiave: {DiffieHellman.ImprontaSegreto(segretoCondiviso)}");
