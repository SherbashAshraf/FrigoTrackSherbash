using System.Net.Http.Json;
using System.Numerics;
using System.Text.Json;
using Comune;

Console.WriteLine("=== Client sensori FrigoTrack ===");

HttpClient http = new HttpClient { BaseAddress = new Uri("http://localhost:5000") };

// ---------- Handshake Diffie-Hellman ----------

// Passo 1: il client sceglie il segreto a e calcola A = g^a mod p
BigInteger segretoClient = DiffieHellman.GeneraSegreto();
BigInteger chiavePubblicaClient = DiffieHellman.CalcolaChiavePubblica(segretoClient);

RichiestaHandshake richiesta = new RichiestaHandshake(
    DiffieHellman.InEsadecimale(DiffieHellman.P),
    DiffieHellman.InEsadecimale(DiffieHellman.G),
    DiffieHellman.InEsadecimale(chiavePubblicaClient));

// Passo 2: invio ad /api/handshake (p, g e A viaggiano in chiaro)
HttpResponseMessage rispostaHandshake = await http.PostAsJsonAsync("/api/handshake", richiesta);
string testoHandshake = await rispostaHandshake.Content.ReadAsStringAsync();

if (!rispostaHandshake.IsSuccessStatusCode)
{
    Console.WriteLine($"Handshake fallito: {(int)rispostaHandshake.StatusCode} {testoHandshake}");
    return;
}

// Anche la risposta dell'handshake deve rispettare il suo schema
ErroreValidazione? erroreHandshake = ValidatoreSchema.Valida("risposta-handshake", testoHandshake);
if (erroreHandshake is not null)
{
    Console.WriteLine($"Risposta dell'handshake non valida. Campo {erroreHandshake.Campo}: {erroreHandshake.Messaggio}");
    return;
}

RispostaHandshake datiRisposta = JsonSerializer.Deserialize<RispostaHandshake>(testoHandshake)!;
BigInteger? chiavePubblicaServer = DiffieHellman.DaEsadecimale(datiRisposta.ChiavePubblicaServer);

if (chiavePubblicaServer is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaServer.Value))
{
    Console.WriteLine("Chiave pubblica del server non valida");
    return;
}

// Passo 3: K = B^a mod p, poi la chiave AES
BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaServer.Value, segretoClient);
byte[] chiave = Cifratura.DerivaChiave(segretoCondiviso);
string idSessione = datiRisposta.IdSessione;

Console.WriteLine($"Handshake completato, sessione {idSessione}");

// ---------- Funzioni per inviare le misure ----------

// Valida la misura con lo schema, la cifra, la invia e mostra la risposta.
// validaPrima = false serve solo per la dimostrazione: manda al server anche una misura sbagliata.
async Task InviaMisura(MisuraSensore misura, bool validaPrima)
{
    string json = JsonSerializer.Serialize(misura);

    // Il client controlla lo schema PRIMA di cifrare
    if (validaPrima)
    {
        ErroreValidazione? errore = ValidatoreSchema.Valida("misura", json);
        if (errore is not null)
        {
            Console.WriteLine($"Misura non inviata. Campo {errore.Campo}: {errore.Messaggio}");
            return;
        }
    }

    BustaCifrata busta = Cifratura.Cifra(idSessione, json, chiave);
    HttpResponseMessage risposta = await http.PostAsJsonAsync("/api/telemetry", busta);
    string corpo = await risposta.Content.ReadAsStringAsync();

    string? testo = LeggiRisposta(corpo);
    if (testo is null)
    {
        Console.WriteLine($"Risposta {(int)risposta.StatusCode} non valida o manomessa");
        return;
    }

    // Anche la risposta decifrata va validata: ack se tutto ok, errore altrimenti
    string nomeSchema = risposta.IsSuccessStatusCode ? "ack" : "errore";
    ErroreValidazione? problema = ValidatoreSchema.Valida(nomeSchema, testo);
    if (problema is not null)
    {
        Console.WriteLine($"Risposta non conforme allo schema {nomeSchema}. Campo {problema.Campo}: {problema.Messaggio}");
        return;
    }

    Console.WriteLine($"Risposta {(int)risposta.StatusCode}: {testo}");
}

// Se il corpo è una busta cifrata la decifra, altrimenti è un errore in chiaro (es. sessione inesistente).
// Restituisce null se la busta è manomessa.
string? LeggiRisposta(string corpo)
{
    try
    {
        BustaCifrata? bustaRisposta = JsonSerializer.Deserialize<BustaCifrata>(corpo);
        if (bustaRisposta?.TestoCifrato != null && bustaRisposta.Tag != null)
            return Cifratura.Decifra(bustaRisposta, chiave);
    }
    catch (JsonException)
    {
    }

    return corpo;
}

// ---------- Dimostrazione ----------

string adesso = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'");

MisuraSensore misuraValida = new MisuraSensore
{
    IdSensore = "CELLA-BG-007",
    DataOra = adesso,
    TipoMerce = "pharma",
    Temperatura = 4.6,
    Umidita = 55,
    Batteria = 87
};

// Stessa misura ma con temperatura impossibile (oltre il massimo di 40 °C)
MisuraSensore misuraNonValida = new MisuraSensore
{
    IdSensore = "CELLA-BG-007",
    DataOra = adesso,
    TipoMerce = "pharma",
    Temperatura = 99,
    Umidita = 55,
    Batteria = 87
};

Console.WriteLine("\n1) Misura valida:");
await InviaMisura(misuraValida, validaPrima: true);

Console.WriteLine("\n2) Misura non valida, bloccata dal client prima della cifratura:");
await InviaMisura(misuraNonValida, validaPrima: true);

Console.WriteLine("\n3) Misura non valida inviata comunque, rifiutata dal server:");
await InviaMisura(misuraNonValida, validaPrima: false);
