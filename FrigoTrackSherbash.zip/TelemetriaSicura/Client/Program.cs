using System.Net.Http.Json;
using System.Numerics;
using System.Text.Json;
using Comune;

Console.WriteLine("=== Client sensori FrigoTrack ===");

HttpClient http = new HttpClient { BaseAddress = new Uri("http://localhost:5000") };

// ---------- Handshake Diffie-Hellman ----------

// Passo 1: il client sceglie il segreto a e calcola A = g^a mod p
BigInteger segretoClient = DiffieHellman.GeneraSegreto();
BigInteger chiavePubblicaClient = DiffieHellman.CalcolaChiavePubblica(segretoClient);

RichiestaHandshake richiesta = new RichiestaHandshake(
    DiffieHellman.InEsadecimale(DiffieHellman.P),
    DiffieHellman.InEsadecimale(DiffieHellman.G),
    DiffieHellman.InEsadecimale(chiavePubblicaClient));

// Passo 2: invio ad /api/handshake (p, g e A viaggiano in chiaro)
HttpResponseMessage rispostaHandshake = await http.PostAsJsonAsync("/api/handshake", richiesta);

if (!rispostaHandshake.IsSuccessStatusCode)
{
    Console.WriteLine($"Handshake fallito: {(int)rispostaHandshake.StatusCode}");
    return;
}

RispostaHandshake? datiRisposta = await rispostaHandshake.Content.ReadFromJsonAsync<RispostaHandshake>();
BigInteger? chiavePubblicaServer = DiffieHellman.DaEsadecimale(datiRisposta?.ChiavePubblicaServer);

if (datiRisposta is null || chiavePubblicaServer is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaServer.Value))
{
    Console.WriteLine("Risposta del server non valida");
    return;
}

// Passo 3: K = B^a mod p, poi la chiave AES
BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaServer.Value, segretoClient);
byte[] chiave = Cifratura.DerivaChiave(segretoCondiviso);
string idSessione = datiRisposta.IdSessione;

Console.WriteLine($"Handshake completato, sessione {idSessione}");

// ---------- Invio di una misura cifrata ----------

MisuraSensore misura = new MisuraSensore
{
    IdSensore = "CELLA-BG-007",
    DataOra = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'"),
    TipoMerce = "pharma",
    Temperatura = 4.6,
    Umidita = 55,
    Batteria = 87
};

// Il JSON viene cifrato e messo in una busta: in rete non viaggia nulla in chiaro
string json = JsonSerializer.Serialize(misura);
BustaCifrata busta = Cifratura.Cifra(idSessione, json, chiave);

HttpResponseMessage rispostaTelemetria = await http.PostAsJsonAsync("/api/telemetry", busta);

if (!rispostaTelemetria.IsSuccessStatusCode)
{
    Console.WriteLine($"Invio fallito: {(int)rispostaTelemetria.StatusCode}");
    return;
}

// Anche la risposta (ack) è una busta cifrata
BustaCifrata? bustaRisposta = await rispostaTelemetria.Content.ReadFromJsonAsync<BustaCifrata>();
string? ack = bustaRisposta is null ? null : Cifratura.Decifra(bustaRisposta, chiave);

Console.WriteLine($"Risposta del server: {ack ?? "busta non valida"}");
