using System.Globalization;
using System.Net.Http.Json;
using System.Numerics;
using System.Text.Json;
using Comune;

// Un sensore simulato. Ogni sensore ha una sessione propria: fa il suo handshake
// e ha la sua chiave, come richiesto dalla consegna.
public class Sensore
{
    private readonly HttpClient http;
    private readonly string idSensore;
    private readonly string tipoMerce;
    private readonly double temperaturaBase;
    private readonly Random casuale = new Random();

    private string idSessione = "";
    private byte[] chiave = Array.Empty<byte>();

    // Alla terza misura la temperatura sale di 6 gradi, per provocare un allarme
    public bool ProvocaAllarme { get; set; }

    // Prova anche una misura non valida e, a sessione chiusa, un nuovo invio (deve dare 401)
    public bool Dimostrazione { get; set; }

    public Sensore(HttpClient http, string idSensore, string tipoMerce, double temperaturaBase)
    {
        this.http = http;
        this.idSensore = idSensore;
        this.tipoMerce = tipoMerce;
        this.temperaturaBase = temperaturaBase;
    }

    // Ciclo di vita del sensore: handshake, misure a intervalli regolari, richiesta delle misure, chiusura
    public async Task Esegui(int numeroMisure, int pausaMillisecondi)
    {
        if (!await EseguiHandshake())
            return;

        for (int numero = 1; numero <= numeroMisure; numero++)
        {
            double temperatura = temperaturaBase + (casuale.NextDouble() - 0.5);
            if (ProvocaAllarme && numero == 3)
                temperatura += 6;

            await InviaMisura(CreaMisura(Math.Round(temperatura, 1)), validaPrima: true);

            // Dimostrazione: una misura con temperatura impossibile
            if (Dimostrazione && numero == 2)
            {
                Scrivi("Prova di una misura non valida (99 °C), bloccata dal client:");
                await InviaMisura(CreaMisura(99), validaPrima: true);

                Scrivi("Stessa misura inviata comunque, rifiutata dal server:");
                await InviaMisura(CreaMisura(99), validaPrima: false);
            }

            await Task.Delay(pausaMillisecondi);
        }

        await RichiediMisure();
        await ChiudiSessione();

        // Dimostrazione: dopo la chiusura la chiave non esiste più sul server
        if (Dimostrazione)
        {
            Scrivi("Invio a sessione chiusa:");
            await InviaMisura(CreaMisura(5), validaPrima: true);
        }
    }

    // ---------- Handshake Diffie-Hellman ----------

    private async Task<bool> EseguiHandshake()
    {
        // Passo 1: il client sceglie il segreto a e calcola A = g^a mod p
        BigInteger segretoClient = DiffieHellman.GeneraSegreto();
        BigInteger chiavePubblicaClient = DiffieHellman.CalcolaChiavePubblica(segretoClient);

        RichiestaHandshake richiesta = new RichiestaHandshake(
            DiffieHellman.InEsadecimale(DiffieHellman.P),
            DiffieHellman.InEsadecimale(DiffieHellman.G),
            DiffieHellman.InEsadecimale(chiavePubblicaClient));

        // Passo 2: invio ad /api/handshake (p, g e A viaggiano in chiaro)
        HttpResponseMessage risposta = await http.PostAsJsonAsync("/api/handshake", richiesta);
        string testo = await risposta.Content.ReadAsStringAsync();

        if (!risposta.IsSuccessStatusCode)
        {
            Scrivi($"Handshake fallito: {(int)risposta.StatusCode} {testo}");
            return false;
        }

        // Anche la risposta dell'handshake deve rispettare il suo schema
        ErroreValidazione? errore = ValidatoreSchema.Valida("risposta-handshake", testo);
        if (errore is not null)
        {
            Scrivi($"Risposta dell'handshake non valida. Campo {errore.Campo}: {errore.Messaggio}");
            return false;
        }

        RispostaHandshake datiRisposta = JsonSerializer.Deserialize<RispostaHandshake>(testo)!;
        BigInteger? chiavePubblicaServer = DiffieHellman.DaEsadecimale(datiRisposta.ChiavePubblicaServer);

        if (chiavePubblicaServer is null || !DiffieHellman.ChiavePubblicaValida(chiavePubblicaServer.Value))
        {
            Scrivi("Chiave pubblica del server non valida");
            return false;
        }

        // Passo 3: K = B^a mod p, poi la chiave AES
        BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaServer.Value, segretoClient);
        chiave = Cifratura.DerivaChiave(segretoCondiviso);
        idSessione = datiRisposta.IdSessione;

        Scrivi($"Handshake completato, sessione {idSessione}");
        return true;
    }

    // ---------- Messaggi applicativi ----------

    private MisuraSensore CreaMisura(double temperatura)
    {
        return new MisuraSensore
        {
            IdSensore = idSensore,
            DataOra = Formatta(DateTime.UtcNow),
            TipoMerce = tipoMerce,
            Temperatura = temperatura,
            Umidita = Math.Round(50 + casuale.NextDouble() * 10, 1),
            Batteria = casuale.Next(60, 100)
        };
    }

    private async Task InviaMisura(MisuraSensore misura, bool validaPrima)
    {
        string json = JsonSerializer.Serialize(misura);
        string? testo = await Invia("/api/telemetry", "misura", json, "ack", validaPrima);
        if (testo is null)
            return;

        RispostaAck ack = JsonSerializer.Deserialize<RispostaAck>(testo)!;
        if (ack.Allarme == true)
            Scrivi($"Misura {misura.Temperatura} °C inviata - ALLARME: {ack.Messaggio}");
        else
            Scrivi($"Misura {misura.Temperatura} °C inviata, ack ok");
    }

    // Chiede al server le misure dell'ultima ora di questo sensore
    private async Task RichiediMisure()
    {
        RichiestaLetture richiesta = new RichiestaLetture
        {
            IdSensore = idSensore,
            Da = Formatta(DateTime.UtcNow.AddHours(-1)),
            A = Formatta(DateTime.UtcNow.AddMinutes(1))
        };

        string? testo = await Invia("/api/readings", "richiesta-readings", JsonSerializer.Serialize(richiesta), "risposta-readings");
        if (testo is null)
            return;

        RispostaLetture risposta = JsonSerializer.Deserialize<RispostaLetture>(testo)!;
        Scrivi($"Il server ha {risposta.Conteggio} misure di questo sensore nell'ultima ora");
    }

    private async Task ChiudiSessione()
    {
        string? testo = await Invia("/api/close", "richiesta-close", JsonSerializer.Serialize(new RichiestaChiusura()), "ack");
        if (testo is not null)
            Scrivi("Sessione chiusa, chiave cancellata");
    }

    // ---------- Invio e ricezione ----------

    // Valida il messaggio con lo schema, lo cifra, lo invia, decifra e valida la risposta.
    // Restituisce il testo della risposta se il server ha risposto 200, altrimenti null.
    // validaPrima = false serve solo per la dimostrazione: manda al server anche un messaggio sbagliato.
    private async Task<string?> Invia(string percorso, string schemaRichiesta, string json, string schemaRisposta, bool validaPrima = true)
    {
        // Il client controlla lo schema PRIMA di cifrare
        if (validaPrima)
        {
            ErroreValidazione? errore = ValidatoreSchema.Valida(schemaRichiesta, json);
            if (errore is not null)
            {
                Scrivi($"Messaggio non inviato. Campo {errore.Campo}: {errore.Messaggio}");
                return null;
            }
        }

        BustaCifrata busta = Cifratura.Cifra(idSessione, json, chiave);
        HttpResponseMessage risposta = await http.PostAsJsonAsync(percorso, busta);
        string corpo = await risposta.Content.ReadAsStringAsync();
        int stato = (int)risposta.StatusCode;

        string? testo = LeggiRisposta(corpo);
        if (testo is null)
        {
            Scrivi($"Risposta {stato} non valida o manomessa");
            return null;
        }

        // Anche la risposta decifrata va validata: lo schema indicato se tutto ok, errore.json altrimenti
        string nomeSchema = risposta.IsSuccessStatusCode ? schemaRisposta : "errore";
        ErroreValidazione? problema = ValidatoreSchema.Valida(nomeSchema, testo);
        if (problema is not null)
        {
            Scrivi($"Risposta non conforme allo schema {nomeSchema}. Campo {problema.Campo}: {problema.Messaggio}");
            return null;
        }

        if (!risposta.IsSuccessStatusCode)
        {
            MessaggioErrore errore = JsonSerializer.Deserialize<MessaggioErrore>(testo)!;
            string campo = errore.Campo is null ? "" : $" (campo: {errore.Campo})";
            Scrivi($"Errore {stato}: {errore.Errore}{campo}");
            return null;
        }

        return testo;
    }

    // Se il corpo è una busta cifrata la decifra, altrimenti è un errore in chiaro (es. sessione inesistente).
    // Restituisce null se la busta è manomessa.
    private string? LeggiRisposta(string corpo)
    {
        try
        {
            BustaCifrata? busta = JsonSerializer.Deserialize<BustaCifrata>(corpo);
            if (busta?.TestoCifrato != null && busta.Tag != null)
                return Cifratura.Decifra(busta, chiave);
        }
        catch (JsonException)
        {
        }

        return corpo;
    }

    private static string Formatta(DateTime istante)
    {
        return istante.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture);
    }

    private void Scrivi(string testo)
    {
        Console.WriteLine($"[{idSensore}] {testo}");
    }
}
