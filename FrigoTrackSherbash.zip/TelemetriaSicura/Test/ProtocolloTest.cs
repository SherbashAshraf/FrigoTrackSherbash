using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Numerics;
using System.Text.Json;
using Comune;
using Microsoft.AspNetCore.Mvc.Testing;
using Server;
using Xunit;

namespace Test;

// Test del protocollo: ogni test parla con il vero server, avviato in memoria da WebApplicationFactory
public class ProtocolloTest : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient http;

    public ProtocolloTest(WebApplicationFactory<Program> fabbrica)
    {
        http = fabbrica.CreateClient();
    }

    // Crea il JSON di una misura valida (si possono cambiare sensore, merce e temperatura)
    private static string CreaMisura(string idSensore = "TEST-BG-001", string tipoMerce = "pharma", double temperatura = 4.6)
    {
        MisuraSensore misura = new MisuraSensore
        {
            IdSensore = idSensore,
            DataOra = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture),
            TipoMerce = tipoMerce,
            Temperatura = temperatura,
            Umidita = 55,
            Batteria = 87
        };
        return JsonSerializer.Serialize(misura);
    }

    // 1. Handshake riuscito
    [Fact]
    public async Task Handshake_Riuscito_ClientEServerHannoLaStessaChiave()
    {
        BigInteger segretoClient = DiffieHellman.GeneraSegreto();
        BigInteger chiavePubblicaClient = DiffieHellman.CalcolaChiavePubblica(segretoClient);

        RichiestaHandshake richiesta = new RichiestaHandshake(
            DiffieHellman.InEsadecimale(DiffieHellman.P),
            DiffieHellman.InEsadecimale(DiffieHellman.G),
            DiffieHellman.InEsadecimale(chiavePubblicaClient));

        HttpResponseMessage risposta = await http.PostAsJsonAsync("/api/handshake", richiesta);
        Assert.Equal(HttpStatusCode.OK, risposta.StatusCode);

        RispostaHandshake dati = (await risposta.Content.ReadFromJsonAsync<RispostaHandshake>())!;
        Assert.Equal(8, dati.IdSessione.Length);

        // Il client calcola la propria chiave...
        BigInteger chiavePubblicaServer = DiffieHellman.DaEsadecimale(dati.ChiavePubblicaServer)!.Value;
        BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaServer, segretoClient);
        byte[] chiaveClient = Cifratura.DerivaChiave(segretoCondiviso);

        // ...e deve essere identica a quella che il server ha salvato per la sessione
        bool sessioneTrovata = Sessioni.Elenco.TryGetValue(dati.IdSessione, out byte[]? chiaveServer);
        Assert.True(sessioneTrovata);
        Assert.True(chiaveClient.SequenceEqual(chiaveServer!));
    }

    // Handshake con parametri diversi dal gruppo noto: rifiutato
    [Fact]
    public async Task Handshake_ConParametriSbagliati_Restituisce400()
    {
        RichiestaHandshake richiesta = new RichiestaHandshake("FFFF", "2", "1A2B");

        HttpResponseMessage risposta = await http.PostAsJsonAsync("/api/handshake", richiesta);

        Assert.Equal(HttpStatusCode.BadRequest, risposta.StatusCode);
    }

    // 2. Messaggio valido
    [Fact]
    public async Task MisuraValida_Restituisce200EConfermaSenzaAllarme()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);

        var (stato, testo) = await sessione.Invia("/api/telemetry", CreaMisura());

        Assert.Equal(HttpStatusCode.OK, stato);
        RispostaAck ack = JsonSerializer.Deserialize<RispostaAck>(testo)!;
        Assert.Equal("ok", ack.Esito);
        Assert.False(ack.Allarme);
    }

    // 3. Messaggio non valido: temperatura oltre il massimo di 40 gradi
    [Fact]
    public async Task MisuraNonValida_Restituisce400IndicandoIlCampo()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);

        var (stato, testo) = await sessione.Invia("/api/telemetry", CreaMisura(temperatura: 99));

        Assert.Equal(HttpStatusCode.BadRequest, stato);
        MessaggioErrore errore = JsonSerializer.Deserialize<MessaggioErrore>(testo)!;
        Assert.Equal("temperature_c", errore.Campo);
    }

    // 4. Busta manomessa: basta cambiare un bit del tag
    [Fact]
    public async Task BustaManomessa_Restituisce400()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);
        BustaCifrata busta = Cifratura.Cifra(sessione.IdSessione, CreaMisura(), sessione.Chiave);

        byte[] tag = Convert.FromBase64String(busta.Tag);
        tag[0] ^= 1;
        BustaCifrata bustaManomessa = busta with { Tag = Convert.ToBase64String(tag) };

        var (stato, _) = await sessione.InviaBusta("/api/telemetry", bustaManomessa);

        Assert.Equal(HttpStatusCode.BadRequest, stato);
    }

    // Anche se si modifica il testo cifrato la busta viene rifiutata
    [Fact]
    public async Task TestoCifratoModificato_Restituisce400()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);
        BustaCifrata busta = Cifratura.Cifra(sessione.IdSessione, CreaMisura(), sessione.Chiave);

        byte[] cifrato = Convert.FromBase64String(busta.TestoCifrato);
        cifrato[cifrato.Length - 1] ^= 1;
        BustaCifrata bustaManomessa = busta with { TestoCifrato = Convert.ToBase64String(cifrato) };

        var (stato, _) = await sessione.InviaBusta("/api/telemetry", bustaManomessa);

        Assert.Equal(HttpStatusCode.BadRequest, stato);
    }

    // 5. Sessione inesistente
    [Fact]
    public async Task SessioneInesistente_Restituisce401()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);
        BustaCifrata busta = Cifratura.Cifra("deadbeef", CreaMisura(), sessione.Chiave);

        var (stato, _) = await sessione.InviaBusta("/api/telemetry", busta);

        Assert.Equal(HttpStatusCode.Unauthorized, stato);
    }

    // Allarme: farmaco a 9,5 gradi (intervallo di sicurezza 2-8)
    [Fact]
    public async Task TemperaturaFuoriIntervallo_RestituisceAllarme()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);

        var (stato, testo) = await sessione.Invia("/api/telemetry", CreaMisura(tipoMerce: "pharma", temperatura: 9.5));

        Assert.Equal(HttpStatusCode.OK, stato);
        RispostaAck ack = JsonSerializer.Deserialize<RispostaAck>(testo)!;
        Assert.True(ack.Allarme);
    }

    // Le misure inviate vengono salvate e si possono rileggere con /api/readings
    [Fact]
    public async Task Readings_RestituisceLeMisureInviate()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);
        await sessione.Invia("/api/telemetry", CreaMisura(idSensore: "PROVA-BG-001"));

        RichiestaLetture richiesta = new RichiestaLetture
        {
            IdSensore = "PROVA-BG-001",
            Da = DateTime.UtcNow.AddHours(-1).ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture),
            A = DateTime.UtcNow.AddMinutes(1).ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture)
        };
        var (stato, testo) = await sessione.Invia("/api/readings", JsonSerializer.Serialize(richiesta));

        Assert.Equal(HttpStatusCode.OK, stato);
        RispostaLetture risposta = JsonSerializer.Deserialize<RispostaLetture>(testo)!;
        Assert.True(risposta.Conteggio >= 1);
        Assert.Equal("PROVA-BG-001", risposta.Misure[0].IdSensore);
    }

    // Sensore che non ha mai inviato misure: 404
    [Fact]
    public async Task Readings_SensoreSconosciuto_Restituisce404()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);

        RichiestaLetture richiesta = new RichiestaLetture
        {
            IdSensore = "CELLA-XX-999",
            Da = "2026-01-01T00:00:00Z",
            A = "2026-12-31T00:00:00Z"
        };
        var (stato, _) = await sessione.Invia("/api/readings", JsonSerializer.Serialize(richiesta));

        Assert.Equal(HttpStatusCode.NotFound, stato);
    }

    // Dopo /api/close la chiave è cancellata e la sessione non esiste più
    [Fact]
    public async Task Close_CancellaLaSessione()
    {
        SessioneProva sessione = await SessioneProva.Apri(http);

        var (statoChiusura, _) = await sessione.Invia("/api/close", "{\"azione\":\"close\"}");
        Assert.Equal(HttpStatusCode.OK, statoChiusura);
        Assert.False(Sessioni.Elenco.ContainsKey(sessione.IdSessione));

        var (statoDopo, _) = await sessione.Invia("/api/telemetry", CreaMisura());
        Assert.Equal(HttpStatusCode.Unauthorized, statoDopo);
    }
}
