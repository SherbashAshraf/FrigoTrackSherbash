using System.Net;
using System.Net.Http.Json;
using System.Numerics;
using System.Text.Json;
using Comune;

namespace Test;

// Un client di prova: fa l'handshake con il server e poi invia messaggi cifrati,
// esattamente come farebbe un sensore.
public class SessioneProva
{
    private readonly HttpClient http;

    public string IdSessione { get; private set; } = "";
    public byte[] Chiave { get; private set; } = Array.Empty<byte>();

    public SessioneProva(HttpClient http)
    {
        this.http = http;
    }

    // Apre una sessione completando l'handshake Diffie-Hellman
    public static async Task<SessioneProva> Apri(HttpClient http)
    {
        SessioneProva sessione = new SessioneProva(http);

        BigInteger segretoClient = DiffieHellman.GeneraSegreto();
        BigInteger chiavePubblicaClient = DiffieHellman.CalcolaChiavePubblica(segretoClient);

        RichiestaHandshake richiesta = new RichiestaHandshake(
            DiffieHellman.InEsadecimale(DiffieHellman.P),
            DiffieHellman.InEsadecimale(DiffieHellman.G),
            DiffieHellman.InEsadecimale(chiavePubblicaClient));

        HttpResponseMessage risposta = await http.PostAsJsonAsync("/api/handshake", richiesta);
        RispostaHandshake dati = (await risposta.Content.ReadFromJsonAsync<RispostaHandshake>())!;

        BigInteger chiavePubblicaServer = DiffieHellman.DaEsadecimale(dati.ChiavePubblicaServer)!.Value;
        BigInteger segretoCondiviso = DiffieHellman.CalcolaSegretoCondiviso(chiavePubblicaServer, segretoClient);

        sessione.IdSessione = dati.IdSessione;
        sessione.Chiave = Cifratura.DerivaChiave(segretoCondiviso);
        return sessione;
    }

    // Cifra un messaggio JSON, lo invia e restituisce il codice HTTP e la risposta decifrata
    public async Task<(HttpStatusCode Stato, string Testo)> Invia(string percorso, string json)
    {
        BustaCifrata busta = Cifratura.Cifra(IdSessione, json, Chiave);
        return await InviaBusta(percorso, busta);
    }

    // Invia una busta già pronta (serve per le buste manomesse o con sessione sbagliata)
    public async Task<(HttpStatusCode Stato, string Testo)> InviaBusta(string percorso, BustaCifrata busta)
    {
        HttpResponseMessage risposta = await http.PostAsJsonAsync(percorso, busta);
        string corpo = await risposta.Content.ReadAsStringAsync();
        return (risposta.StatusCode, Leggi(corpo));
    }

    // Se il corpo è una busta cifrata la decifra, altrimenti è un errore in chiaro
    private string Leggi(string corpo)
    {
        try
        {
            BustaCifrata? busta = JsonSerializer.Deserialize<BustaCifrata>(corpo);
            if (busta?.TestoCifrato != null && busta.Tag != null)
                return Cifratura.Decifra(busta, Chiave) ?? "(busta non valida)";
        }
        catch (JsonException)
        {
        }

        return corpo;
    }
}
