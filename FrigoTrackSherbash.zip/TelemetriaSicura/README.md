# Telemetria sicura per la catena del freddo

Progetto TEP 5IB - prototipo per FrigoTrack S.r.l.

Sistema client-server HTTP in C# (.NET 8) in cui i sensori inviano misure in JSON,
cifrate con una chiave concordata tramite Diffie-Hellman e validate con JSON Schema.

## Struttura

- `Comune` - libreria condivisa (Diffie-Hellman, cifratura, validazione, messaggi)
- `Server` - server di raccolta dati (ASP.NET Core, porta 5000)
- `Client` - simulatore dei sensori
- `schemas` - uno schema JSON per ogni tipo di messaggio

## Avvio

1. Aprire `TelemetriaSicura.sln` con Visual Studio 2022 (al primo avvio viene scaricato il pacchetto NuGet `JsonSchema.Net`)
2. Avviare prima `Server`, poi `Client`
   (oppure `dotnet run --project Server` e `dotnet run --project Client` da due terminali)

## Protocollo

1. **Handshake** (`POST /api/handshake`): il client invia `p`, `g` e `A` in chiaro,
   il server risponde con `session_id` e `B`. Entrambi calcolano `K` e ne ricavano
   la chiave AES-256 (SHA-256 del segreto condiviso). La chiave non viaggia mai in rete.
2. **Messaggi cifrati**: ogni messaggio viaggia in una busta con `session_id`,
   `ciphertext` e `tag` (Base64). La cifratura è AES-GCM; il nonce è messo davanti al testo cifrato.

| Endpoint | Contenuto della busta | Risposta (anch'essa in busta) |
|----------|-----------------------|-------------------------------|
| `POST /api/handshake` | `p`, `g`, `A` (in chiaro) | `session_id`, `B` (in chiaro) |
| `POST /api/telemetry` | misura del sensore | ack, con `allarme` se la temperatura esce dall'intervallo di sicurezza |
| `POST /api/readings` | sensore e intervallo (`from`, `to`) | elenco delle misure |
| `POST /api/close` | `{"azione": "close"}` | ack; la sessione e la chiave vengono cancellate |

Il server prima decifra e poi valida: se la decifratura o il tag falliscono risponde 400
senza elaborare nulla. Codici usati: 200 tutto ok, 400 messaggio non valido o busta manomessa,
401 sessione inesistente (mai aperta o già chiusa), 404 sensore sconosciuto.

## Allarmi e salvataggio

- Intervalli di sicurezza: farmaci (`pharma`) 2-8 °C; alimenti (`food`) 0-4 °C; surgelati (`frozen`) da -25 a -18 °C.
  Solo il primo è indicato dalla consegna, gli altri due sono valori scelti da noi.
- Le misure valide vengono salvate nel file `dati/misure.json`, accanto all'eseguibile del server
  (`Server/bin/Debug/net8.0/dati/`), e si consultano con `/api/readings`.

## Schemi JSON (cartella `schemas/`)

| File | Messaggio |
|------|-----------|
| `richiesta-handshake.json` | corpo di `/api/handshake` |
| `risposta-handshake.json` | risposta di `/api/handshake` |
| `busta.json` | busta cifrata (tutti gli scambi dopo l'handshake) |
| `misura.json` | misura del sensore |
| `ack.json` | conferma del server (con eventuale allarme) |
| `richiesta-close.json` | richiesta di chiusura sessione |
| `richiesta-readings.json` | richiesta di `/api/readings` (sensore e intervallo) |
| `risposta-readings.json` | risposta di `/api/readings` |
| `errore.json` | messaggio di errore |

Gli schemi usano `type`, `required`, `enum`, `minimum`/`maximum`, `pattern`, `format` e
`additionalProperties: false`. Il client valida la misura prima di cifrarla; il server
valida ogni messaggio in ingresso dopo averlo decifrato. Un messaggio non valido viene
rifiutato con un errore (`errore.json`) che indica il campo sbagliato; l'errore di una
misura già decifrata viaggia a sua volta cifrato, perché può contenere il valore inviato.

## Stato del lavoro

- [x] Handshake Diffie-Hellman
- [x] Busta cifrata e `/api/telemetry`
- [x] JSON Schema e validazione
- [x] `/api/readings`, `/api/close`, salvataggio e allarmi, tre sensori
- [ ] Test e relazione
