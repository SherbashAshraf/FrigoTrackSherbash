# Telemetria sicura per la catena del freddo

Progetto TEP 5IB - prototipo per FrigoTrack S.r.l.

Sistema client-server HTTP in C# (.NET 8) in cui i sensori inviano misure in JSON,
cifrate con una chiave concordata tramite Diffie-Hellman e validate con JSON Schema.

## Struttura

- `Comune` - libreria condivisa (Diffie-Hellman, messaggi)
- `Server` - server di raccolta dati (ASP.NET Core, porta 5000)
- `Client` - simulatore dei sensori

## Avvio

1. Aprire `TelemetriaSicura.sln` con Visual Studio 2022
2. Avviare prima `Server`, poi `Client`
   (oppure `dotnet run --project Server` e `dotnet run --project Client` da due terminali)

## Stato del lavoro

- [x] Handshake Diffie-Hellman
- [ ] Busta cifrata e `/api/telemetry`
- [ ] JSON Schema
- [ ] `/api/readings`, `/api/close`, salvataggio e allarmi
- [ ] Test e relazione
