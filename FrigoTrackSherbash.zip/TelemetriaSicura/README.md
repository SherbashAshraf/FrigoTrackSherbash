# Telemetria sicura per la catena del freddo

Progetto TEP 5IB - prototipo per FrigoTrack S.r.l.

Sistema client-server HTTP in C# (.NET 8) in cui i sensori inviano misure in JSON,
cifrate con una chiave concordata tramite Diffie-Hellman e validate con JSON Schema.

## Struttura

- `Comune` - libreria condivisa (Diffie-Hellman, cifratura, messaggi)
- `Server` - server di raccolta dati (ASP.NET Core, porta 5000)
- `Client` - simulatore dei sensori

## Avvio

1. Aprire `TelemetriaSicura.sln` con Visual Studio 2022
2. Avviare prima `Server`, poi `Client`
   (oppure `dotnet run --project Server` e `dotnet run --project Client` da due terminali)

## Protocollo

1. **Handshake** (`POST /api/handshake`): il client invia `p`, `g` e `A` in chiaro,
   il server risponde con `session_id` e `B`. Entrambi calcolano `K` e ne ricavano
   la chiave AES-256 (SHA-256 del segreto condiviso). La chiave non viaggia mai in rete.
2. **Messaggi cifrati** (`POST /api/telemetry`): ogni messaggio viaggia in una busta
   con `session_id`, `ciphertext` e `tag` (Base64). La cifratura è AES-GCM; il nonce
   è messo davanti al testo cifrato.

Il server prima decifra e poi elabora: se la decifratura o il tag falliscono risponde 400.
Se la sessione non esiste risponde 401.

## Stato del lavoro

- [x] Handshake Diffie-Hellman
- [x] Busta cifrata e `/api/telemetry`
- [ ] JSON Schema
- [ ] `/api/readings`, `/api/close`, salvataggio e allarmi
- [ ] Test e relazione
